import React from 'react'

const ApplyDoctor = () => {
  return (
    <div>ApplyDoctor</div>
  )
}

export default ApplyDoctor